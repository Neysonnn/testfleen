<?php
namespace app\forms;

use std, gui, framework, app;


class news2 extends AbstractForm
{

}