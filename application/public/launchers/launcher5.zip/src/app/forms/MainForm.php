<?php
namespace app\forms;

use std, gui, framework, app;

/*

█──█──███──████
█─█────█───█──█
██─────█───█──█
█─█────█───█──█
█──█───█───████


█──█──███
█──█──█
████──███
█──█──█
█──█──███


█─█──█──█──████──███──████────██
█─█──█─█───█──█────█──█──█───█─█
███──██────████──███──████──█──█
──█──█─█───█──█────█──█──█──█──█
███──█──█──█──█──███──█──█──█──█


████──████───███──████──████──████
█──█──█──██───█───█──█──█──█──█──█
████──████────█───█──█──████──████
█──█──█──██───█───█──█──█─────█──█──█
█──█──████────█───████──█─────█──█──█


███──████──███
─█───█──█───█
─█───█──█───█
─█───█──█───█
─█───████───█


████──█──█───███───████──████
█──█──█──█───█─█───█──█──█──█
█──█──█─██───█─█───█──█──████
█──█──██─█──█████──█──█──█
█──█──█──█──█───█──████──█
*/

class MainForm extends AbstractForm
{

    /**
     * @event exit_button.click 
     */
    function doExit_buttonClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event play_button.click 
     */
    function doPlay_buttonClick(UXMouseEvent $e = null)
    {    
        $n = "\n";
        $name = $this->name->text;
        $this->main_hider->show();
        $this->choose_server->show();
        execute(sprintf("reg add HKCU\\Software\\SAMP /v PlayerName /d \"%s\" /f", $name));
        file_put_contents('C:\launcher\settings\name.ini', $this->name->text);
        $hFile = fopen("C:\launcher\settings.ini", "a+");
        fwrite($hFile, $name. $n);

    }

    /**
     * @event news_page1.click 
     */
    function doNews_page1Click(UXMouseEvent $e = null)
    {    
        $this->news1->show();
        $this->news2->hide();
        $this->news3->hide();
        $this->news_page1->color = $this->news_page_clicked_button_color->text;
        $this->news_page2->color = '#333333';
        $this->news_page3->color = '#333333';
    }

    /**
     * @event news_page2.click 
     */
    function doNews_page2Click(UXMouseEvent $e = null)
    {    
        $this->news1->hide();
        $this->news2->show();
        $this->news3->hide();
        $this->news_page2->color = $this->news_page_clicked_button_color->text;
        $this->news_page1->color = '#333333';
        $this->news_page3->color = '#333333';
    }

    /**
     * @event news_page3.click 
     */
    function doNews_page3Click(UXMouseEvent $e = null)
    {    
        $this->news1->hide();
        $this->news2->hide();
        $this->news3->show();
        $this->news_page3->color = $this->news_page_clicked_button_color->text;
        $this->news_page2->color = '#333333';
        $this->news_page1->color = '#333333';
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {   
        $this->form('servers')->monitoring_1_ip->text = $this->monitoring_1_ip->text;
        $this->form('servers')->monitoring_2_ip->text = $this->monitoring_2_ip->text;
        $this->form('servers')->monitoring_3_ip->text = $this->monitoring_3_ip->text;
        $this->form('servers')->monitoring_1_name->text = $this->monitoring_1_name->text;
        $this->form('servers')->monitoring_2_name->text = $this->monitoring_2_name->text;
        $this->form('servers')->monitoring_3_name->text = $this->monitoring_3_name->text;
        file_put_contents('C:\launcher\gta.txt', '');
        $savedname = file_get_contents('C:\launcher\settings\name.ini');
        $this->name->text = $savedname; 
        fs::makeDir('C:\launcher\settings');
        fs::makeFile('C:\launcher\settings\name.ini');
        fs::makeFile('C:\launcher\settings\folder.ini');
        fs::makeFile('C:\launcher\settings\gameExists.ini');
        file_put_contents('C:\launcher\settings\name.ini', $this->name->text);
        //file_put_contents('C:\launcher\settings\folder.ini', '');
        //file_put_contents('C:\launcher\settings\gameExists.ini', '');
        $this->news_page1->color = $this->news_page_clicked_button_color->text;
        $this->news1->show();
        $gameExists = file_get_contents('C:\launcher\settings\gameExists.ini');
        if ($this->downloadEnabled->text == 'true'){
            if ($gameExists == 'true'){
            $this->progress_name->text = 'Игра готова к запуску...';
            }else{
            $this->download_button->show();
            }
        }
        
    }

    /**
     * @event button3.click 
     */
    function doButton3Click(UXMouseEvent $e = null)
    {    
        $folder = $this->folder->text;
        $settings = "\settings.ini";
        fs::makeDir($folder);
        //fs::makeFile($folder. $settings);
        fs::makeFile("C:\launcher\settings.ini");
    }

    /**
     * @event download_button.click 
     */
    function doDownload_buttonClick(UXMouseEvent $e = null)
    {
       $this->choose_folder->show();
       $this->main_hider->show();
       //$this->loadForm('choose_folder');
    }

    /**
     * @event settings_button.mouseDown 
     */
    function doSettings_buttonMouseDown(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event settings_button.click 
     */
    function doSettings_buttonClick(UXMouseEvent $e = null)
    {    
        $this->settings->show();
        $this->main_hider->show();
    }

    /**
     * @event discord_link.click 
     */
    function doDiscord_linkClick(UXMouseEvent $e = null)
    {    
        if ($this->discord_url->text == ''){
            ;
        }else{
            browse($this->discord_url->text);
        }
    }

    /**
     * @event vk_group_link.click 
     */
    function doVk_group_linkClick(UXMouseEvent $e = null)
    {    
        if ($this->vk_url->text == ''){
            ;
        }else{
            browse($this->vk_url->text);
        }
    }

    /**
     * @event site_link.click 
     */
    function doSite_linkClick(UXMouseEvent $e = null)
    {    
        if ($this->site_url->text == ''){
            ;
        }else{
            browse($this->site_url->text);
        }
    }


}
