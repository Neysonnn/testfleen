<?php
namespace app\forms;

use std, gui, framework, app;


class news3 extends AbstractForm
{

}