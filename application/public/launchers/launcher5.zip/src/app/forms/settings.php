<?php
namespace app\forms;

use std, gui, framework, app;


class settings extends AbstractForm
{

    /**
     * @event link.click 
     */
    function doLinkClick(UXMouseEvent $e = null)
    {    
        browse('https://vk.com/amid24');
    }

    /**
     * @event button.click 
     */
    function doButtonClick(UXMouseEvent $e = null)
    {    
        $this->form('MainForm')->settings->hide();
        $this->form('MainForm')->main_hider->hide();
    }

    /**
     * @event buttonAlt.click 
     */
    function doButtonAltClick(UXMouseEvent $e = null)
    {    
        file_put_contents('C:\launcher\settings\folder.ini', $this->gameFolder->text);
        $this->form('MainForm')->settings->hide();
        $this->form('MainForm')->main_hider->hide();
    }

    /**
     * @event gameFolder_check.click 
     */
    function doGameFolder_checkClick(UXMouseEvent $e = null)
    {    
        $foldercheck = $this->gameFolder->text;
        $sampexe = '\samp.exe';
        if (file_exists($foldercheck. $sampexe)){
            $this->buttonAlt->enabled = true;
        }else{
            $this->toast('Путь не найден.');
        }
        $this->buttonAlt->enabled = false;
    }

}
