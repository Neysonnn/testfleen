<?php
namespace app\forms;

use std, gui, framework, app;

/*

█──█──███──████
█─█────█───█──█
██─────█───█──█
█─█────█───█──█
█──█───█───████


█──█──███
█──█──█
████──███
█──█──█
█──█──███


█─█──█──█──████──███──████────██
█─█──█─█───█──█────█──█──█───█─█
███──██────████──███──████──█──█
──█──█─█───█──█────█──█──█──█──█
███──█──█──█──█──███──█──█──█──█


████──████───███──████──████──████
█──█──█──██───█───█──█──█──█──█──█
████──████────█───█──█──████──████
█──█──█──██───█───█──█──█─────█──█──█
█──█──████────█───████──█─────█──█──█


███──████──███
─█───█──█───█
─█───█──█───█
─█───█──█───█
─█───████───█


████──█──█───███───████──████
█──█──█──█───█─█───█──█──█──█
█──█──█─██───█─█───█──█──████
█──█──██─█──█████──█──█──█
█──█──█──█──█───█──████──█
*/

class choose_server extends AbstractForm
{

    /**
     * @event button.click 
     */
    function doButtonClick(UXMouseEvent $e = null)
    {    
        $this->form("MainForm")->main_hider->hide();
        $this->form('MainForm')->choose_server->hide();
    }

    /**
     * @event server1.click 
     */
    function doServer1Click(UXMouseEvent $e = null)
    {    
        $folder = file_get_contents('C:\launcher\settings\folder.ini');
        $sampexe = '\samp.exe ';
        $ip1 = $this->server1ip->text;
        execute($folder. $sampexe. $ip1);
    }

    /**
     * @event server2.click 
     */
    function doServer2Click(UXMouseEvent $e = null)
    {    
        $folder = file_get_contents('C:\launcher\settings\folder.ini');
        $sampexe = '\samp.exe ';
        $ip2 = $this->server2ip->text;
        execute($folder. $sampexe. $ip2);
    }

    /**
     * @event server3.click 
     */
    function doServer3Click(UXMouseEvent $e = null)
    {    
        $folder = file_get_contents('C:\launcher\settings\folder.ini');
        $sampexe = '\samp.exe ';
        $ip3 = $this->server3ip->text;
        execute($folder. $sampexe. $ip3);
    }

}
