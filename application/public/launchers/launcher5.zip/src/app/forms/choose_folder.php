<?php
namespace app\forms;

use std, gui, framework, app;


class choose_folder extends AbstractForm
{

    /**
     * @event buttonAlt.click 
     */
    function doButtonAltClick(UXMouseEvent $e = null)
    {    
        $this->form('MainForm')->main_hider->hide();
        $this->form('MainForm')->choose_folder->hide();
        $this->loadForm('MainForm');
    }

    /**
     * @event button.click 
     */
    function doButtonClick(UXMouseEvent $e = null)
    {    
        /*
        $this->loadForm('MainForm');
        $this->form('MainForm')->download->show();
        $this->form('MainForm')->progressBar->hide();
        $this->form('MainForm')->progress_name->hide();
        */
    }

    /**
     * @event button3.click 
     */
    function doButton3Click(UXMouseEvent $e = null)
    {    
        $folder = '\launcher';
        $fullfolder = $this->folder->text. $folder;
        $file = '\gta.txt';
        fs::makeDir($fullfolder);
        //file_put_contents($fullfolder. $file, '1');
        file_put_contents('C:\launcher\gta.txt', '');
        file_put_contents('C:\launcher\settings\folder.ini', $fullfolder);
        $this->form('MainForm')->download->show();
        $this->form('MainForm')->progressBar->hide();
        $this->form('MainForm')->progress_name->hide();
        $this->form('MainForm')->choose_folder->hide();
        $this->form('MainForm')->main_hider->hide();
        
        /*
        file_put_contents('C:\launcher\gtasa.txt', 'wait...');
        $this->loadForm('MainForm');
        $this->form('MainForm')->download->show();
        $this->form('MainForm')->progressBar->hide();
        $this->form('MainForm')->progress_name->hide();
        $folder = $this->folder->text;
        $launcher = '\launcher';
        $gtasa = '\gtasa.zip';
        file_put_contents('C:\launcher\settings\folder.ini', $folder. $launcher);
        if ($folder == ""){
            $this->toast('Укажите путь!');
        }else{
           fs::makeDir($folder. $launcher); 
           fs::makeFile($folder. $launcher. $gtasa);
        }
        $this->loadForm('MainForm');
        $this->form('MainForm')->download->show();
        $this->form('MainForm')->progressBar->hide();
        $this->form('MainForm')->progress_name->hide();
        */
    }

}
