<?php
namespace app\forms;

use std, gui, framework, app;

/*

█──█──███──████
█─█────█───█──█
██─────█───█──█
█─█────█───█──█
█──█───█───████


█──█──███
█──█──█
████──███
█──█──█
█──█──███


█─█──█──█──████──███──████────██
█─█──█─█───█──█────█──█──█───█─█
███──██────████──███──████──█──█
──█──█─█───█──█────█──█──█──█──█
███──█──█──█──█──███──█──█──█──█


████──████───███──████──████──████
█──█──█──██───█───█──█──█──█──█──█
████──████────█───█──█──████──████
█──█──█──██───█───█──█──█─────█──█──█
█──█──████────█───████──█─────█──█──█


███──████──███
─█───█──█───█
─█───█──█───█
─█───█──█───█
─█───████───█


████──█──█───███───████──████
█──█──█──█───█─█───█──█──█──█
█──█──█─██───█─█───█──█──████
█──█──██─█──█████──█──█──█
█──█──█──█──█───█──████──█
*/

class servers extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $this->monitoring_1_name->text = $this->form('MainForm')->monitoring_1_name->text;
        $this->monitoring_2_name->text = $this->form('MainForm')->monitoring_2_name->text;
        $this->monitoring_3_name->text = $this->form('MainForm')->monitoring_3_name->text;
        
        $this->monitoring_1_ip->text = $this->form('MainForm')->monitoring_1_ip->text;
        $this->monitoring_2_ip->text = $this->form('MainForm')->monitoring_2_ip->text;
        $this->monitoring_3_ip->text = $this->form('MainForm')->monitoring_3_ip->text;
    }

}
