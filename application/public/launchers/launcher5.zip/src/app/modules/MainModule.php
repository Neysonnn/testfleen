<?php
namespace app\modules;

use std, gui, framework, app;
use ZipArchive;


class MainModule extends AbstractModule
{

    /**
     * @event jdownloader.complete 
     */
    function doJdownloaderComplete(ScriptEvent $e = null)
    {    
        /*
        $folder = file_get_contents('C:\launcher\settings\folder.ini');
        $zip = '\gta.zip';
        $fullfolder = $folder. $zip;
        rename('C:\launcher\gta.txt', 'C:\launcher\gta.zip');
        fs::move('C:\launcher\gta.zip', $fullfolder);
        */
        
        
        //file_put_contents('C:\launcher\gta.txt', '');
        
        rename('C:\launcher\gta.txt', 'C:\launcher\gta.zip');
        $folder = file_get_contents('C:\launcher\settings\folder.ini');
        $folderfile = $folder. '\gta.zip';
        fs::move('C:\launcher\gta.zip', $folderfile);
        
        $this->form('MainForm')->download->hide();
        $this->form('MainForm')->download_button->hide();
        $this->form('MainForm')->progressBar->show();
        $this->form('MainForm')->progress_name->show();
        
        if ($this->form('MainForm')->autounzip->text == 'true'){
            $zip = new ZipArchive;
            $zip->open('C:\launcher\gta.zip')
            $zip->extractTo($folder);
            $zip->close();
        }
        
        
        /*$this->form('MainForm')->download->hide();
        $this->form('MainForm')->download_button->hide();
        $folder = file_get_contents('C:\launcher\folder.ini');
        $launcher = '\launcher';
        fs::makeDir($folder. $launcher);
        fs::move('C:\launcher\gtasa.txt', $folder);
        $gtasa = '\gtasa.txt';
        $gtasazip = '\gtasa.zip'; 
        fs::rename($folder. $gtasa, $folder. $gtasazip);
        //rename($folder. $gtasa, $folder);
        
        $this->form('MainForm')->download->hide();
        $this->form('MainForm')->download_button->hide();
        $folder = file_get_contents('C:\launcher\folder.ini');
        file_put_contents('C:\launcher\settings\gameExists.ini', 'true');
        $gtasa_temp = '\gtasa.txt';
        $gtasa_newname - '\gtasa.zip';
        if (file_exists($folder. $gtasa_temp)){
            fs::move('C:\launcher\data\gtasa.txt', $folder);
            rename($folder. $gtasa_temp, $folder. $gtasa_newname);
        }
        */
    }

}
