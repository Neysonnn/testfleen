﻿namespace Launcher
{
    partial class Main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnPlayButton = new Guna.UI2.WinForms.Guna2Button();
            this.Input_Login = new Guna.UI2.WinForms.Guna2TextBox();
            this.X = new System.Windows.Forms.PictureBox();
            this.wind = new System.Windows.Forms.PictureBox();
            this.magazine = new System.Windows.Forms.PictureBox();
            this.forum = new System.Windows.Forms.PictureBox();
            this.comment = new System.Windows.Forms.PictureBox();
            this.news = new System.Windows.Forms.PictureBox();
            this.download = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.ok = new System.Windows.Forms.PictureBox();
            this.lblDownloadState = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wind)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.magazine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.forum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.news)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ok)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(177)))), ((int)(((byte)(169)))));
            this.label1.Location = new System.Drawing.Point(185, 285);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Онлайн:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnPlayButton
            // 
            this.btnPlayButton.Animated = true;
            this.btnPlayButton.BackColor = System.Drawing.Color.Transparent;
            this.btnPlayButton.BorderRadius = 11;
            this.btnPlayButton.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.btnPlayButton.CheckedState.Parent = this.btnPlayButton;
            this.btnPlayButton.CustomImages.Parent = this.btnPlayButton;
            this.btnPlayButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnPlayButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnPlayButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnPlayButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnPlayButton.DisabledState.Parent = this.btnPlayButton;
            this.btnPlayButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.btnPlayButton.Font = new System.Drawing.Font("Geometria", 20.25F, System.Drawing.FontStyle.Bold);
            this.btnPlayButton.ForeColor = System.Drawing.Color.White;
            this.btnPlayButton.HoverState.Parent = this.btnPlayButton;
            this.btnPlayButton.Location = new System.Drawing.Point(38, 695);
            this.btnPlayButton.Name = "btnPlayButton";
            this.btnPlayButton.ShadowDecoration.Parent = this.btnPlayButton;
            this.btnPlayButton.Size = new System.Drawing.Size(300, 75);
            this.btnPlayButton.TabIndex = 7;
            this.btnPlayButton.Text = "Играть";
            this.btnPlayButton.Click += new System.EventHandler(this.btnPlayButton_Click);
            // 
            // Input_Login
            // 
            this.Input_Login.Animated = true;
            this.Input_Login.BackColor = System.Drawing.Color.Transparent;
            this.Input_Login.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Input_Login.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(97)))), ((int)(((byte)(0)))));
            this.Input_Login.BorderRadius = 8;
            this.Input_Login.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Input_Login.DefaultText = "";
            this.Input_Login.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Input_Login.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Input_Login.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Input_Login.DisabledState.Parent = this.Input_Login;
            this.Input_Login.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Input_Login.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(97)))), ((int)(((byte)(0)))));
            this.Input_Login.FocusedState.BorderColor = System.Drawing.Color.Transparent;
            this.Input_Login.FocusedState.Parent = this.Input_Login;
            this.Input_Login.Font = new System.Drawing.Font("Geometria", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Input_Login.ForeColor = System.Drawing.Color.White;
            this.Input_Login.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.Input_Login.HoverState.Parent = this.Input_Login;
            this.Input_Login.IconLeft = ((System.Drawing.Image)(resources.GetObject("Input_Login.IconLeft")));
            this.Input_Login.IconLeftSize = new System.Drawing.Size(29, 30);
            this.Input_Login.Location = new System.Drawing.Point(283, 34);
            this.Input_Login.Margin = new System.Windows.Forms.Padding(4);
            this.Input_Login.Name = "Input_Login";
            this.Input_Login.PasswordChar = '\0';
            this.Input_Login.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(197)))), ((int)(((byte)(163)))));
            this.Input_Login.PlaceholderText = "Введите ваше имя";
            this.Input_Login.SelectedText = "";
            this.Input_Login.ShadowDecoration.Parent = this.Input_Login;
            this.Input_Login.Size = new System.Drawing.Size(278, 64);
            this.Input_Login.TabIndex = 8;
            this.Input_Login.TextOffset = new System.Drawing.Point(10, 0);
            // 
            // X
            // 
            this.X.BackColor = System.Drawing.Color.Transparent;
            this.X.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("X.BackgroundImage")));
            this.X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.X.Cursor = System.Windows.Forms.Cursors.Hand;
            this.X.Location = new System.Drawing.Point(1136, 21);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(35, 28);
            this.X.TabIndex = 9;
            this.X.TabStop = false;
            this.X.Click += new System.EventHandler(this.X_Click);
            // 
            // wind
            // 
            this.wind.BackColor = System.Drawing.Color.Transparent;
            this.wind.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("wind.BackgroundImage")));
            this.wind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.wind.Cursor = System.Windows.Forms.Cursors.Hand;
            this.wind.Location = new System.Drawing.Point(1104, 31);
            this.wind.Name = "wind";
            this.wind.Size = new System.Drawing.Size(35, 28);
            this.wind.TabIndex = 10;
            this.wind.TabStop = false;
            this.wind.Click += new System.EventHandler(this.wind_Click);
            // 
            // magazine
            // 
            this.magazine.BackColor = System.Drawing.Color.Transparent;
            this.magazine.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("magazine.BackgroundImage")));
            this.magazine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.magazine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.magazine.Location = new System.Drawing.Point(604, 47);
            this.magazine.Name = "magazine";
            this.magazine.Size = new System.Drawing.Size(99, 33);
            this.magazine.TabIndex = 12;
            this.magazine.TabStop = false;
            this.magazine.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // forum
            // 
            this.forum.BackColor = System.Drawing.Color.Transparent;
            this.forum.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("forum.BackgroundImage")));
            this.forum.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.forum.Cursor = System.Windows.Forms.Cursors.Hand;
            this.forum.Location = new System.Drawing.Point(724, 47);
            this.forum.Name = "forum";
            this.forum.Size = new System.Drawing.Size(85, 33);
            this.forum.TabIndex = 13;
            this.forum.TabStop = false;
            this.forum.Click += new System.EventHandler(this.forum_Click);
            // 
            // comment
            // 
            this.comment.BackColor = System.Drawing.Color.Transparent;
            this.comment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("comment.BackgroundImage")));
            this.comment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.comment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comment.Location = new System.Drawing.Point(840, 47);
            this.comment.Name = "comment";
            this.comment.Size = new System.Drawing.Size(185, 33);
            this.comment.TabIndex = 14;
            this.comment.TabStop = false;
            this.comment.Click += new System.EventHandler(this.comment_Click);
            // 
            // news
            // 
            this.news.BackColor = System.Drawing.Color.Transparent;
            this.news.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("news.BackgroundImage")));
            this.news.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.news.Cursor = System.Windows.Forms.Cursors.Hand;
            this.news.Location = new System.Drawing.Point(585, 217);
            this.news.Name = "news";
            this.news.Size = new System.Drawing.Size(586, 375);
            this.news.TabIndex = 15;
            this.news.TabStop = false;
            // 
            // download
            // 
            this.download.BackColor = System.Drawing.Color.Transparent;
            this.download.BorderRadius = 4;
            this.download.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.download.Location = new System.Drawing.Point(445, 757);
            this.download.Name = "download";
            this.download.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.download.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.download.ShadowDecoration.Parent = this.download;
            this.download.Size = new System.Drawing.Size(738, 11);
            this.download.TabIndex = 16;
            this.download.Text = "guna2ProgressBar1";
            this.download.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // ok
            // 
            this.ok.BackColor = System.Drawing.Color.Transparent;
            this.ok.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ok.BackgroundImage")));
            this.ok.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ok.Cursor = System.Windows.Forms.Cursors.Default;
            this.ok.Location = new System.Drawing.Point(445, 710);
            this.ok.Name = "ok";
            this.ok.Size = new System.Drawing.Size(41, 41);
            this.ok.TabIndex = 17;
            this.ok.TabStop = false;
            // 
            // lblDownloadState
            // 
            this.lblDownloadState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.lblDownloadState.Font = new System.Drawing.Font("Geometria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDownloadState.ForeColor = System.Drawing.Color.White;
            this.lblDownloadState.Location = new System.Drawing.Point(491, 719);
            this.lblDownloadState.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDownloadState.Name = "lblDownloadState";
            this.lblDownloadState.Size = new System.Drawing.Size(363, 26);
            this.lblDownloadState.TabIndex = 18;
            this.lblDownloadState.Text = "Для запуска игры нажмите «Играть»";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1228, 810);
            this.ControlBox = false;
            this.Controls.Add(this.lblDownloadState);
            this.Controls.Add(this.ok);
            this.Controls.Add(this.download);
            this.Controls.Add(this.news);
            this.Controls.Add(this.comment);
            this.Controls.Add(this.forum);
            this.Controls.Add(this.magazine);
            this.Controls.Add(this.wind);
            this.Controls.Add(this.X);
            this.Controls.Add(this.Input_Login);
            this.Controls.Add(this.btnPlayButton);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Launcher [Unreal]";
            this.Load += new System.EventHandler(this.Main_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Main_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Main_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wind)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.magazine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.forum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.news)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ok)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private Guna.UI2.WinForms.Guna2Button btnPlayButton;
        private Guna.UI2.WinForms.Guna2TextBox Input_Login;
        private System.Windows.Forms.PictureBox X;
        private System.Windows.Forms.PictureBox wind;
        private System.Windows.Forms.PictureBox magazine;
        private System.Windows.Forms.PictureBox forum;
        private System.Windows.Forms.PictureBox comment;
        private System.Windows.Forms.PictureBox news;
        private Guna.UI2.WinForms.Guna2ProgressBar download;
        private System.Windows.Forms.PictureBox ok;
        private System.Windows.Forms.Label lblDownloadState;
    }
}

