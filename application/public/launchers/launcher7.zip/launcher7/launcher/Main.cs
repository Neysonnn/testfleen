﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Security.Principal;
using Newtonsoft.Json;
using System.Drawing;
using System.Windows.Threading;
using SevenZipExtractor;

namespace Launcher
{
    public partial class Main : Form
    {
        private DispatcherTimer timer = null;
        private string archiveYaDiskLinsk = "";
        private BackgroundWorker backgroundWorkerUnpacker = null;
        private string downloadedArchivePath = string.Empty;
        private Action playButtonAction;
        private string gamePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CRMP");
        public Main()
        {
            
            InitializeComponent();

            //запускаем1 раз 

            SampQuery api = new SampQuery(User.ip, 7777, 'i');

            var response = api.read();
            var online_players = response["players"];
            var maxplayers = response["maxplayers"];

            this.label1.Text = "Онлайн: " + online_players + "/" + maxplayers;
            //потом обновляем в таймере


            timer = new DispatcherTimer();
            timer.Tick += new EventHandler(timer1_Tick);
            timer.Interval = new TimeSpan(0, 0, 0, 0, 10000);
            timer.Start();

            Animator.Start();
            UserSave Usave = new UserSave();

             try
             {

                 using (StreamReader sw = new StreamReader(Directory.GetCurrentDirectory() + "/set.json"))
                 {

                     string json = sw.ReadToEnd();
                     Usave = JsonConvert.DeserializeObject<UserSave>(json);
                     User.nickname = Usave.nickname;
                     User.path = Usave.path;
                     sw.Close();
                 }
             }
             catch
             {

             }
            SetPlayMode(Installed());

        }
        private void SetPlayMode(bool playStartMode)
        {
            if (playStartMode)
            {
                btnPlayButton.Text = "ИГРАТЬ";

                SetPlayButtonFunction(PlayAction);
            }
            else
            {
                btnPlayButton.Text = "УСТАНОВКА";

                SetPlayButtonFunction(InstallAction);
            }
        }
        public void SetPlayButtonFunction(Action action)
        {
            playButtonAction = action;
        }
        private bool Installed()
        {
            string[] checkFiles =
            {
                "gta_sa.exe",
                "gta_sa.exe"
            };

            for (int i = 0; i < checkFiles.Length; i++)
            {
                if (File.Exists(Path.Combine(gamePath, checkFiles[i])) == false)
                    return false;
            }

            return true;
        }

        private void InstallAction()
        {
            string DownloadPath = gamePath;
            DirectoryInfo DownloadDir = new DirectoryInfo(DownloadPath);
            if (DownloadDir.Exists == false)
                DownloadDir.Create();

            //DownloadFileFromYandexDisk(archiveYaDiskLinsk, DownloadPath, out string DownloadedFilePath);
            DownloadFile(archiveYaDiskLinsk, DownloadPath, out string DownloadedFilePath);
            downloadedArchivePath = DownloadedFilePath;
        }
        private void DownloadFile(string URL, string TargetPath, out string DownloadedFilePath)
        {
            DownloadedFilePath = Path.Combine(TargetPath, Path.GetFileName(URL));

            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Proxy = null;
                    client.DownloadProgressChanged += Client_DownloadProgressChanged;
                    client.DownloadFileCompleted += Client_DownloadFileCompleted;
                    client.DownloadFileAsync(new Uri(URL), DownloadedFilePath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка в DownloadFile", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
        }
        private void PlayAction()
        {
            string nick = Input_Login.Text;
            string sid = WindowsIdentity.GetCurrent().User.Value;
            string nickgame = sid + "\\Software\\SAMP";
            RegistryKey saveKey = Registry.Users.CreateSubKey(nickgame);
            saveKey.SetValue("PlayerName", nick);
            Process.Start("CRMP\\RODINA.lnk", "CRMP\\gta_sa.exe" + " -c -n " + Input_Login.Text + "-h 82.202.197.109 -p 7777");
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        Point LastPoint;
        private void border_MouseDown(object sender, MouseEventArgs e)
        {
            LastPoint = new Point(e.X, e.Y);
        }

        private void border_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - LastPoint.X;
                this.Top += e.Y - LastPoint.Y;
            }
        }

        private void but_close_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void save_login_Click(object sender, EventArgs e)
        {
            UserSave Usave = new UserSave();
            Usave.nickname = User.nickname = Input_Login.Text;

            Usave.path = User.path;
            String serialized = JsonConvert.SerializeObject(Usave);

            using (StreamWriter sw = new StreamWriter(Directory.GetCurrentDirectory() + "/set.json"))
            {
                sw.Write(serialized);
                sw.Close();
            }
        }
        private void Client_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                lblDownloadState.Text = "Скачивание отменено!";
                MessageBox.Show(lblDownloadState.Text, "Скачивание файла", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                //guna2Button5.Enabled = true;
                btnPlayButton.Enabled = true;
            }
            else if (e.Error != null)
            {
                lblDownloadState.Text = "Ошибка!";
                MessageBox.Show(e.Error.ToString(), "Скачивание файла", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                //guna2Button5.Enabled = true;
                btnPlayButton.Enabled = true;
            }
            else
            {
                lblDownloadState.Text = "Распаковка...";

                StartUnpack(); // <-- Тут вызываем метод для старта распаковки архива
            }
        }

        private void Client_DownloadProgressChanged(object sender, System.Net.DownloadProgressChangedEventArgs e)
        {
            if (e.TotalBytesToReceive == -1)
            {
                download.Value = 0;
                lblDownloadState.Text = "Начало скачивания...";
            }
            else
            {
                double bytesIn = e.BytesReceived;
                double totalBytes = e.TotalBytesToReceive;
                double percentage = bytesIn / totalBytes * 100;
                download.Value = (int)percentage;
                lblDownloadState.Text = $"Скачивание: {e.ProgressPercentage}%";
            }


            // Ну можно и так (вместо того что выше):
            //lblDownloadState.Text = $"Скачивание  {e.ProgressPercentage}%";
        }

        /// <summary>
        /// Распаковывает архив
        /// </summary>
        /// <param name="ArchivePath">Расположение файла для распаковки</param>
        private bool UnpackArchive(string ArchivePath)
        {
            string path = Path.GetDirectoryName(Path.GetFullPath(ArchivePath)); //Path.Combine(Path.GetDirectoryName(Path.GetFullPath(ArchivePath)), "Unpacked");

            try
            {
                using (ArchiveFile archiveFile = new ArchiveFile(ArchivePath))
                {
                    double totalFiles = (long)archiveFile.Entries.Count;
                    double completed = 0;

                    foreach (Entry entry in archiveFile.Entries)
                    {
                        entry.Extract(Path.Combine(path, entry.FileName));

                        completed++;
                        var percentComplete = Math.Round((double)(100 * completed) / totalFiles, 2);
                        Invoke(new MethodInvoker(() =>
                        {
                            lblDownloadState.Text = $"Распаковка: {percentComplete:N2}%";
                            download.Value = (int)percentComplete;
                        }));
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Распаковка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
        }

        private void StartUnpack()
        {
            backgroundWorkerUnpacker = new BackgroundWorker();
            backgroundWorkerUnpacker.DoWork += BackgroundWorkerUnpacker_DoWork;
            backgroundWorkerUnpacker.WorkerReportsProgress = true;
            backgroundWorkerUnpacker.WorkerSupportsCancellation = true;

            backgroundWorkerUnpacker.RunWorkerAsync();
        }

        private void BackgroundWorkerUnpacker_DoWork(object sender, DoWorkEventArgs e)
        {
            if (UnpackArchive(downloadedArchivePath))
            {
                Invoke(new MethodInvoker(() => lblDownloadState.Text = "Установка завершилась, удачной игры!"));
                MessageBox.Show(lblDownloadState.Text, string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);

                Invoke(new MethodInvoker(() => SetPlayMode(Installed())));
            }
            else
            {
                Invoke(new MethodInvoker(() => lblDownloadState.Text = "Скачивание завершено, но распаковка не удалась!"));
                MessageBox.Show(lblDownloadState.Text, string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //Invoke(new MethodInvoker(() => guna2Button7.Enabled = true));
            Invoke(new MethodInvoker(() => btnPlayButton.Enabled = true));
        }

        private void folder_browser_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                string destFileName = folderBrowserDialog1.SelectedPath + "/samp.exe";
                if (File.Exists(destFileName))
                {
                    User.path = folderBrowserDialog1.SelectedPath;
                    UserSave Usave = new UserSave();
                    Usave.path = folderBrowserDialog1.SelectedPath;
                    Usave.nickname = User.nickname;
                    string serialized = JsonConvert.SerializeObject(Usave);
                    using (StreamWriter sw = new StreamWriter(Directory.GetCurrentDirectory() + "/set.json"))
                    {
                        sw.Write(serialized);
                        sw.Close();
                    }
                }
                else MessageBox.Show("Указан неверный путь, samp.exe не найден!");


            }
        }

        private void inGame_Click(object sender, EventArgs e)
        {

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            SampQuery api = new SampQuery(User.ip, 7777, 'i');

            var response = api.read();
            var online_players = response["players"];
            var maxplayers = response["maxplayers"];

            this.label1.Text = "Онлайн: " + online_players + "/" + maxplayers;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
        }

        private void Input_Login_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void X_Click(object sender, EventArgs e)
        {
            UserSave Usave = new UserSave();
            Usave.nickname = User.nickname = Input_Login.Text;

            Usave.path = User.path;
            String serialized = JsonConvert.SerializeObject(Usave);

            using (StreamWriter sw = new StreamWriter(Directory.GetCurrentDirectory() + "/set.json"))
            {
                sw.Write(serialized);
                sw.Close();
            }

            this.Close();
        }

        private void wind_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void border_Click(object sender, EventArgs e)
        {

        }

        private void Main_MouseDown(object sender, MouseEventArgs e)
        {
            LastPoint = new Point(e.X, e.Y);
        }

        private void Main_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - LastPoint.X;
                this.Top += e.Y - LastPoint.Y;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Process.Start("//: тут ваша ссылка на site");
        }

        private void forum_Click(object sender, EventArgs e)
        {
            Process.Start("//: тут ваша ссылка на forum");
        }

        private void comment_Click(object sender, EventArgs e)
        {
            Process.Start("//: тут ваша ссылка на comment");
        }

        private void btnPlayButton_Click(object sender, EventArgs e)
        {
            playButtonAction.Invoke();
        }
    }
    static public class User
    {
        public static string nickname = "Nickname";
        public static string path = " ";
        public static string ip = "54.37.142.74";
    }
    public class UserSave
    {
        public string nickname = "Nickname";
        public string path = " ";
    }
}
