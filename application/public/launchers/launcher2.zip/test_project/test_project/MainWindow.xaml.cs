﻿using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Security.Principal;
using System.Windows;
using System.Windows.Input;
using SampQueryApi;
using SettingsLauncher;

namespace test_project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //загрузка новостей
        int load_games = Settings.games;
        string IP_CONNECT = (string)Settings.ip;
        string URL_GAMES = (string)Settings.url;
        string IP_QUERY = (string)Settings.api;



        public MainWindow()
        {

            try
            {
                //Настройка API SAMP
                SampQuery api = new SampQuery(IP_QUERY, 7777); //PORT СМЕНИТЬ 
                SampServerInfoData data = api.GetServerInfo();

                //компоненты
                InitializeComponent();

                //настройки счетчика API
                player.Content = data.Players + " / " + data.MaxPlayers;
                progress2.Value = data.Players;

                //Настройка новостей
                
                    //текст
                info.Content = NewsSettings.text;
                info.FontSize = 10; //шрифт ( 10 - нормально видно )

                     //заголовок
                text_up.Content = NewsSettings.up;
                text_up.FontSize = 16;



            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }
       
        //загрузка + запуск ( проверка )
        void FindeGamesFile()
        {
            try
            {
                var exePath = AppDomain.CurrentDomain.BaseDirectory;
                var path_config = System.IO.Path.Combine(exePath, "fh221.paks");
                if(File.Exists(path_config))
                {
                    load_games = 1;
                    info_text.Content = "Проверка файлов завершена. Игра готова к запуску!";
                }

            }
            catch (Exception ex)
            {
                 MessageBox.Show(ex.Message);
            }
        }

        void GamesStartLoading()
        {
            FindeGamesFile();
            var exePath = AppDomain.CurrentDomain.BaseDirectory;
            var bin = System.IO.Path.Combine(exePath, "bin/GtaSA/");
            if (load_games == 0)
            {
                try
                {
                    WebClient webclient = new WebClient();
                    var path = System.IO.Path.Combine(exePath, "game_blaze.zip");
                    Uri uri = new Uri(URL_GAMES);
                    Stopwatch sw = new Stopwatch();
                    webclient.DownloadFileAsync(uri, path);
                    webclient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(webClient_DownloadProgressChanged);
                    webclient.DownloadFileCompleted += new System.ComponentModel.AsyncCompletedEventHandler(webClient_DownloadFileCompleted);
                    void webClient_DownloadProgressChanged(object sender, System.Net.DownloadProgressChangedEventArgs e)
                    {
                        progress1.Value = e.ProgressPercentage;
                        text_2.Content = "" + (Convert.ToDouble(e.BytesReceived) / 1024 / 1024).ToString("0,00") + " МБ" + "  /  " + (Convert.ToDouble(e.TotalBytesToReceive) / 1024 / 1024).ToString("0.00") + " МБ";
                    }
                    void webClient_DownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
                    {
                        string sourceArchiveFileName = "game_blaze.zip";
                        progress1.Value = 0;
                        ZipFile.ExtractToDirectory(sourceArchiveFileName, bin);
                        System.IO.File.Delete(path);
                        info_text.Content = "Загрузка игры завершена.";
                        load_games = 1;
                        var path_game = System.IO.Path.Combine(exePath, "fh221.paks");
                        File.Create(path_game);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            else Start();

        }
        void Start()
        {
            try
            {
                if (text1.Text == "Nick_Name")
                {
                    MessageBox.Show("Вы не указали NickName", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else if (text1.Text == "")
                {
                    MessageBox.Show("Вы не указали NickName", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else if (text1.Text == "Nick")
                {
                    MessageBox.Show("Вы не указали NickName", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else if(text1.Text == "Введите ваш ник")
                {
                    MessageBox.Show("Вы не указали NickName", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                var exePath = AppDomain.CurrentDomain.BaseDirectory;


                var samp = System.IO.Path.Combine(exePath, "bin/GtaSA/samp.exe");
                var gta_sa = System.IO.Path.Combine(exePath, "bin/GtaSA/gta_sa.exe");

                //сборки запускать нельзя, только если она ваша и есть samp.exe
                if (System.IO.File.Exists(samp) || System.IO.File.Exists(gta_sa))
                {
                    string nick = text1.Text;
                    string sid = WindowsIdentity.GetCurrent().User.Value;
                    string nick_user = sid + "\\Software\\SAMP";
                    RegistryKey savekey = Registry.Users.CreateSubKey(nick_user);
                    savekey.SetValue("PlayerName", nick);
                    savekey.Close();
                    Process.Start(samp, IP_CONNECT);
                    //System.Diagnostics.Process.Start(samp, "-c -n " + nick + " -h 127.0.0.1 -p 7777");


                }
                else MessageBox.Show("У вас не найдены системные файлы для старта игры.\n" + "Скачать вы можете их на форуме");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Двигательные функции Form + Закрывание формы и сворачивание 

        //закрыть
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        //сворачивание
        private void Button_2(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }
        //перетягивание
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //магазин
            System.Diagnostics.Process.Start("http://vk.com/");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //сайт
            System.Diagnostics.Process.Start("http://vk.com/");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            //форум
            System.Diagnostics.Process.Start("http://vk.com/");
        }
        //запуск и проверка
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            GamesStartLoading();
        }
    }
}
