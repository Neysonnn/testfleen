﻿using test_project;

namespace SettingsLauncher
{
    class Settings
    {
        //настройки
        public static short games = 1;
        public static object ip = "127.0.0.1";
        public static object url = "vk.com";
        public static object api = "185.169.134.4";
        public static object app_update = "vk.com/update_archive.zip";
    }
    class Launcher
    {
        //настройки лаунчера ( визуально не отображаются )

        public static object app_version = "1.7.3";
        public static object name = "Name Project";
    }
    class NewsSettings
    {
        public static object text = "Уважаемые игроки штата. Сегодня наш проект \n" +
            "открылся. Если вы хотите нас поддержать,\n" +
            "то подпишитесь на группу проекта.\n" +
            "Группа проекта: vk.com/weckek";

        public static object up = "Новое обновление\n" +
            "Казино";
        
        
    }

}